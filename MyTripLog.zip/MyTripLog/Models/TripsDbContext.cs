﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace MyTripLog.Models
{




    public class TripsDbContext : DbContext
    {

        public TripsDbContext(DbContextOptions<TripsDbContext> options) : base(options) { }



        public DbSet<MyTrips> Trips { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);



            modelBuilder.Entity<MyTrips>().HasData(
                new MyTrips
                {
                    TripId = 1,
                    Arrival = new DateTime(2024, 01, 01),
                    Departure = new DateTime(2024, 01, 06),
                    Destination = "mexcio",
                    Accommodations = "none",
                    ThingsToDo1 = "vist a church "



                }
            );
              











        }    
    }   


}
