﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace MyTripLog.Models
{




    public class TripsDbContext : DbContext //Dbcontext class for managing the database
    {

        public TripsDbContext(DbContextOptions<TripsDbContext> options) : base(options) { }
        //takes Dbcontext options  and passes them to the base class


        public DbSet<MyTrips> Trips { get; set; }
        //trips in the tbale in database

        protected override void OnModelCreating(ModelBuilder modelBuilder)//configure model and seed data
        {
            base.OnModelCreating(modelBuilder);//base implementaion 



            modelBuilder.Entity<MyTrips>().HasData(
                new MyTrips
                {
                    TripId = 1,
                    Arrival = new DateTime(2024, 01, 01),
                    Departure = new DateTime(2024, 01, 06),
                    Destination = "mexico",
                    Accommodations = "none",
                    ThingsToDo1 = "visit a church "



                }//seeding database with data (1 row)
            );
        }    
    }   


}
