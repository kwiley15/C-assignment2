﻿using System.ComponentModel.DataAnnotations;

namespace MyTripLog.Models
{
    public class MyTrips
    {
        [Key]
        public int TripId { get; set; }

        [Required(ErrorMessage = "the Destination is required")]
        public required String Destination { get; set; }

        [Required(ErrorMessage = "The Arrival date is required")]
        public required DateTime Arrival { get; set; }

        [Required(ErrorMessage = "The Departure date is required")]
        public required DateTime Departure { get; set; }

        public string? Accommodations { get; set; }

        public string? AccommodationPhone { get; set; }
            
        public string? AccommodationEmail { get; set; }


        public string? ThingsToDo1 { get; set; }

        public string? ThingsToDo2 { get; set; }

        public string? ThingsToDo3 { get; set; }









    }
}
