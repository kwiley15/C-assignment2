﻿using System.ComponentModel.DataAnnotations;

namespace MyTripLog.Models
{
    public class MyTrips
    {
        [Key]
        public int TripId { get; set; }

        [Required(ErrorMessage = "the Destination is required")]
        public required String Destination { get; set; } //Destination is required and must be provided 

        [Required(ErrorMessage = "The Arrival date is required")]
        public required DateTime Arrival { get; set; } // Arrival is required and must be provided 

        [Required(ErrorMessage = "The Departure date is required")]
        public required DateTime Departure { get; set; } // Departure is required and must be provided 



        public string? Accommodations { get; set; } //optional field to store accommodations detail

        public string? AccommodationPhone { get; set; } // optional phone number for accommodations
            
        public string? AccommodationEmail { get; set; } //optional email for accommodations 



        //optional fields to store activities or points of interest for the trip 
        public string? ThingsToDo1 { get; set; }

        public string? ThingsToDo2 { get; set; }

        public string? ThingsToDo3 { get; set; }









    }
}
