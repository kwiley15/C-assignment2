using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MyTripLog.Models;

namespace MyTripLog.Controllers;

public class HomeController : Controller
{
    private readonly TripsDbContext _context; //for interacting with the database

    public HomeController(TripsDbContext context)
    {
       
        _context = context;
        //assigning a injected database context to a privtate field
        
    }

    public IActionResult Index()//handles request of home page
    {
        ViewBag.recentlyAdded = TempData["Destination"];
        var trips = _context.Trips.ToList(); //retireves all from database and stores in a list
        TempData.Clear(); // clears stored temp values
        return View(trips); //return view and passing to the list of tirps to be displayed
        
    }

  
}
