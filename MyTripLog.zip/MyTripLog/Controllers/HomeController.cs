using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MyTripLog.Models;

namespace MyTripLog.Controllers;

public class HomeController : Controller
{
    private readonly TripsDbContext _context;

    public HomeController(TripsDbContext context)
    {
       
        _context = context;
        
    }

    public IActionResult Index()
    {
        ViewBag.recentlyAdded = TempData["Destination"];
        var trips = _context.Trips.ToList();
        TempData.Clear();
        return View(trips);
        
    }

  
}
