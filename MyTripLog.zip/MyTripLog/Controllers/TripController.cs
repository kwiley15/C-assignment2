﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyTripLog.Models;

namespace MyTripLog.Controllers
{   

  
    public class TripController : Controller
    {

        private readonly TripsDbContext _context;

        public TripController(TripsDbContext context)
        {
            _context = context;
        }

        
        [HttpGet]
        public IActionResult AddTrip()
        {
            return View();
        }
        
        [HttpPost]
        public IActionResult AddTrip(MyTrips trips)
        {
            if (ModelState.IsValid)
            {
                TempData["Destination"] = trips.Destination;
                TempData["Arrival"] = trips.Arrival;
                TempData["Departure"] = trips.Departure;
                TempData["Accommodations"] = trips.Accommodations;

                TempData.Keep();

                if(!string.IsNullOrEmpty(trips.Accommodations))
                {
                    return RedirectToAction("TripAccommodations");
                }
                else
                {
                    return RedirectToAction("ThingsToDo");
                }
               


            }
            return View(trips);

        }

        

        [HttpGet]
        public IActionResult TripAccommodations()
        {
           
            if (TempData["Accommodations"] == null)
            {
                return RedirectToAction("AddTrip");
            }


            ViewData["SubHead"] = TempData["Accommodations"];

            TempData.Keep();
            return View();
        }

        [HttpPost]
        public IActionResult TripAccommodations(MyTrips trips)
        {
            TempData["AccommodationPhone"] = trips.AccommodationPhone;
            TempData["AccommodationsEmail"] = trips.AccommodationEmail;

            TempData.Keep();

            return RedirectToAction("ThingsToDo");

        }


        [HttpGet]
        public IActionResult ThingsToDo()
        {
            if (TempData["Destination"] == null)
            {
                return RedirectToAction("AddTrip");
            }

            ViewData["Subhead"] = TempData["Destination"];

            TempData.Keep();
            return View();

        }

        [HttpPost]
        public IActionResult ThingsToDo(MyTrips trips)
        {
            if (ModelState.IsValid)
            {



                

                _context.Trips.Add(trips);
                _context.SaveChanges();




            }

            
            return RedirectToAction("Index", "Home");
        }



        public IActionResult Cancel()
        {
            TempData.Clear();
            return RedirectToAction("Index", "Home");
        }


    }
}
