﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyTripLog.Models;

namespace MyTripLog.Controllers
{   

  
    public class TripController : Controller
    {

        private readonly TripsDbContext _context; // to interact with the database

        public TripController(TripsDbContext context)
        {
            _context = context;
            // Assigning the injected database context to a private field
        }


        [HttpGet]
        public IActionResult AddTrip()//displays form for adding new trip
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddTrip(MyTrips trips)// handles form submission for adding a new trip
        {
            if (ModelState.IsValid) // validate the model before starting
            {
                TempData["Destination"] = trips.Destination;
                TempData["Arrival"] = trips.Arrival;
                TempData["Departure"] = trips.Departure;
                TempData["Accommodations"] = trips.Accommodations;
                //stores temp values

                TempData.Keep();//keep those values acorss many requests

                if(!string.IsNullOrEmpty(trips.Accommodations))//redirct based on if accommodations was provided 
                {
                    return RedirectToAction("TripAccommodations");
                }
                else
                {
                    return RedirectToAction("ThingsToDo");
                }
            }
            return View(trips); //if anything fails reload the form 
        }


        [HttpGet]
        public IActionResult TripAccommodations()//displays the trip accommodation page 
        {
           
            if (TempData["Accommodations"] == null)
            {
                return RedirectToAction("AddTrip");
            }


            ViewData["SubHead"] = TempData["Accommodations"]; //pass accommodations data to the view using viewdata

            TempData.Keep(); // keeping values for futher use
            return View();
        }

        [HttpPost]
        public IActionResult TripAccommodations(MyTrips trips) //handles form submission for accommodations
        {
            TempData["AccommodationPhone"] = trips.AccommodationPhone;
            TempData["AccommodationsEmail"] = trips.AccommodationEmail;
            //additional accommodation detials 

            TempData.Keep();//keep values for futher use

            return RedirectToAction("ThingsToDo");//redirct to the next page (page 3)

        }


        [HttpGet]
        public IActionResult ThingsToDo()//displays the things to do page
        {
            if (TempData["Destination"] == null)
            {
                return RedirectToAction("AddTrip");
            }

            ViewData["Subhead"] = TempData["Destination"];//passing destination data to the view using view data

            TempData.Keep(); //keep values for futher use
            return View(); 

        }

        [HttpPost]
        public IActionResult ThingsToDo(MyTrips trips)//handles from data submission for things to do page
        {
            if (ModelState.IsValid) //validate before saing to the database
            {
                _context.Trips.Add(trips); //adding the new trip to the database
                _context.SaveChanges(); //save changes to the database

            }

            
            return RedirectToAction("Index", "Home"); //reutrn to home page after saving 
        }



        public IActionResult Cancel()//cancels adding new trip
        {
            TempData.Clear(); //clears all values 
            return RedirectToAction("Index", "Home"); //returns the user to the home page 
        }


    }
}
